﻿CREATE TABLE [dbo].[Mechanic] (
    [Id]          INT           IDENTITY (1, 1) NOT NULL,
    [Description] VARCHAR (250) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

