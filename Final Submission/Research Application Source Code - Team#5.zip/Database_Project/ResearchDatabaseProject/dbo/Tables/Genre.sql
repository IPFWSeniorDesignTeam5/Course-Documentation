﻿CREATE TABLE [dbo].[Genre] (
    [Id]          INT           IDENTITY (1, 1) NOT NULL,
    [Description] VARCHAR (250) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

