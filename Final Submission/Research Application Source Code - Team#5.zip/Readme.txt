Solution developed in Microsoft Visual Studio 2015

Standalone Executable requirements:
Microsoft .NET 4.5
Microsoft SQL Server Express Local DB (Community 2015, DB Server version 852 or greater)