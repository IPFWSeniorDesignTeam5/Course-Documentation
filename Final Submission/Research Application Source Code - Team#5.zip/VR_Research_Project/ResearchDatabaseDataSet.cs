﻿namespace VR_Research_Project
{


    partial class ResearchDatabaseDataSet
    {
    }
}
